export class GlobalVariable {
  static apiUrl = {
    // local url
    // mainUrl: "http://localhost:1337/",

    // test server
    mainUrl: 'https://food-recipe.zignuts.dev/api/',
  };
  static timeStampForNewNotificationCall = 30000; //in milliseconds
}
